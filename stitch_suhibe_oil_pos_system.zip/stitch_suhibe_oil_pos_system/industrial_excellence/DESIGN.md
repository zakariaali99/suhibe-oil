---
name: Industrial Excellence
colors:
  surface: '#fcf8ff'
  surface-dim: '#dbd9e1'
  surface-bright: '#fcf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2fb'
  surface-container: '#f0ecf5'
  surface-container-high: '#eae7f0'
  surface-container-highest: '#e4e1ea'
  on-surface: '#1b1b21'
  on-surface-variant: '#464652'
  inverse-surface: '#303036'
  inverse-on-surface: '#f2eff8'
  outline: '#777683'
  outline-variant: '#c7c5d4'
  surface-tint: '#4f54b4'
  primary: '#15157d'
  on-primary: '#ffffff'
  primary-container: '#2e3192'
  on-primary-container: '#9da1ff'
  inverse-primary: '#c0c1ff'
  secondary: '#505f76'
  on-secondary: '#ffffff'
  secondary-container: '#d0e1fb'
  on-secondary-container: '#54647a'
  tertiary: '#491a00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6c2a00'
  on-tertiary-container: '#f19160'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#04006d'
  on-primary-fixed-variant: '#373a9b'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb692'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#773207'
  background: '#fcf8ff'
  on-background: '#1b1b21'
  surface-variant: '#e4e1ea'
typography:
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: 0em
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.05em
  status-badge:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  grid_columns: '12'
  gutter: 24px
  margin: 32px
---

## Brand & Style

The design system is engineered for the high-stakes environment of oil retail and inventory management. It projects an aura of absolute reliability, precision, and modern efficiency. The brand personality is grounded and professional, designed to instill confidence in shop owners while remaining accessible to frontline staff.

The visual style follows a **Corporate Modern** movement. It utilizes generous whitespace to reduce cognitive load during complex inventory tasks, combined with high-contrast interactive elements to drive transactional speed. The aesthetic is clean and "engineered," favoring structural integrity and clarity over decorative flair.

## Colors

The palette is anchored by **Deep Indigo**, a color associated with stability and institutional trust. This is used for navigation, headers, and core branding elements. **Slate Gray** serves as the functional secondary color, providing a neutral foundation for borders, icons, and deactivated states.

For primary conversion points—specifically the 'Checkout' flow and final confirmation actions—a **Vibrant Emerald Green** is employed to provide high visibility and a psychological sense of "completion." 

The background remains a pure white to maximize contrast, while a subtle slate-50 or slate-100 is used for surface layering to distinguish between different data modules. Status colors for Paid (Success), Pending (Warning), and Unpaid (Error) follow standard semantic patterns but are saturation-balanced to remain legible against the white and indigo backdrop.

## Typography

The design system utilizes **Inter** for its exceptional legibility in data-heavy SaaS environments. The type scale is strictly hierarchical to ensure that critical metrics (like inventory levels or total sales) are instantly recognizable.

Headlines use a tighter letter-spacing and heavier weights to command attention, while body copy is optimized with a 1.6 line-height to ensure readability during long periods of use. Labels for form fields and table headers use an uppercase treatment with increased tracking to create a clear visual distinction between metadata and user data.

## Layout & Spacing

This design system employs a **12-column fluid grid** for the main content area, allowing the POS interface to adapt from desktop workstations to tablet devices. A 4px baseline grid ensures vertical rhythm across all components.

Layouts should prioritize "elegant breathing room." Wide margins (32px) and consistent gutters (24px) prevent the dense inventory data from feeling overwhelming. Grouping is achieved through consistent padding within cards—typically 24px (lg)—to ensure content is never cramped against borders.

## Elevation & Depth

Depth in this design system is conveyed through **Tonal Layers** and **Ambient Shadows**. Instead of dramatic shadows, we use a sophisticated combination of 1px borders in `slate-100` and very soft, diffused shadows (0px 4px 20px rgba(0,0,0,0.05)).

Surface levels are defined as follows:
1. **Background (Level 0):** Pure White (#FFFFFF).
2. **Cards & Modules (Level 1):** Subtle shadow and 1px border.
3. **Hover States & Modals (Level 2):** Increased shadow spread (0px 10px 30px rgba(0,0,0,0.08)) to indicate interactivity or focus.

This approach maintains a clean, flat appearance while providing the tactile feedback necessary for a professional interface.

## Shapes

The shape language balance reliability (straight lines) with modern approachability (rounded corners). Core containers such as metric cards and data tables use a **16px (rounded-xl)** radius to soften the industrial nature of the data.

Small interactive elements like buttons and input fields use a tighter **8px (rounded-lg)** radius to maintain a crisp, professional edge. Status badges and tags utilize a fully pill-shaped (999px) radius to distinguish them from actionable buttons.

## Components

### Buttons
Primary action buttons utilize high-contrast backgrounds. The "Checkout" button is uniquely styled in the Emerald Green accent, while standard primary buttons use Deep Indigo. All buttons feature a 200ms ease-in-out transition on hover, shifting the background color slightly darker.

### Detailed Tables
Tables are the backbone of the system. They feature a clean `slate-50` header row with uppercase labels. Rows have a subtle bottom border (`slate-100`) and a soft-blue background tint on hover to assist with horizontal tracking.

### Metric Cards & Sparklines
Metric cards display a large H2 value, a secondary label, and a simplified sparkline chart. Sparklines should use a 2px stroke width and reflect the color of the trend (Green for up, Red for down), rendered with a soft gradient fill beneath the path.

### Status Badges
Badges are semi-transparent with a 10% opacity background of their respective semantic color and a 100% opacity text label. 
- **Paid:** Green background 10%, Green text.
- **Pending:** Yellow background 10%, Dark Orange text.
- **Unpaid:** Red background 10%, Red text.

### Input Fields
Inputs use a 1px `slate-200` border that transitions to `deep-indigo` on focus. Labels sit outside the field for maximum clarity during high-speed data entry.